<script src="<?=ROOT?>/assets/bootstrap.min.js"></script>
</div>

</body>
</html>