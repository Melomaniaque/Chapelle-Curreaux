<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- google font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ephesis&display=swap" rel="stylesheet">
    <!-- ----- -->

    <link rel="stylesheet" type="text/css" href="<?= ROOT ?>/assets/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= ROOT ?>/assets/all.min.css">
    <style>
        nav{

            background-image: url("https://images.pexels.com/photos/1560093/pexels-photo-1560093.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940");
            background-position: unset;

        }
        body{


        }

        h1, h2, h4, p{
            font-size: xx-large;
            font-family: 'Ephesis', cursive;
        }
        a{
            font-family: 'Ephesis', cursive;
            font-size: 1.4rem;
        }
    </style>
    <title>Home</title>
</head>
<body>
<style>
    .fa{
        margin-left: 4px;
    }
</style>
<div style="min-width: 350px;">