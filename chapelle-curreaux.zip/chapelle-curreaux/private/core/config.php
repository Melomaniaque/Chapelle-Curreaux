<?php

define('ROOT', 'http://127.0.0.1/chapelle-curreaux/public');
// il faut penser a changer l'url lors de la mise en ligne du site

define('ASSETS', 'http://127.0.0.1/chapelle-curreaux/public/assets');


define('DBNAME', 'mediatheque');
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBPASS', '');
define('DBDRIVER', 'mysql');